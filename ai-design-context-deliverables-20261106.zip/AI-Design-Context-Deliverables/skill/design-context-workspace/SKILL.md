---
name: design-context-workspace
description: Create and operate Git-backed AI design workspaces for requirements analysis, solution design, structured PRDs, reviews, baselines, demand decomposition, traceability, and SQLite query indexes. Use when work must preserve structured design objects and their relationships; do not use for ordinary prose-only planning or software task execution.
---

# Design Context Workspace

Use the bundled CLI to keep design facts traceable and recoverable. Git-managed YAML and artifacts are authoritative; `.workspace/index.db` is a disposable query projection.

## Start

Resolve this skill directory, then invoke:

```bash
python3 <skill-dir>/scripts/design_context.py --root <workspace> <command>
```

If `<workspace>/workspace.yaml` is absent, initialize it with `init --name <name>`. Do not initialize over an unrelated directory without checking its contents.

Before modifying an existing workspace, run `validate` and `index status`. After a group of mutations, run `validate`, rebuild the index when stale, and verify the requested trace or baseline outcome.

## Choose the work mode

- For object shape, IDs, relations, lifecycle state, and baseline semantics, read [references/domain-model.md](references/domain-model.md).
- For requirement analysis, solution design, PRD, review, and decomposition sequencing, read [references/workflows.md](references/workflows.md) only for the active mode.
- For PRD creation or rendering, also read [references/prd-ownership.md](references/prd-ownership.md).
- For exact commands and exit behavior, read [references/cli-reference.md](references/cli-reference.md).

## Invariants

- Edit design objects through the CLI. Never write business facts directly to SQLite.
- Local IDs are 19 digits: UTC `YYYYMMDDHHmmss` plus a zero-padded five-digit random value. Enforce uniqueness and retry collisions.
- Keep external RR/IR/SR/US identifiers in `ExternalReference`, never in the local primary key.
- Use `expectedRevision` on updates. Surface conflicts; never silently overwrite another Agent's change.
- Treat review targets and baselines as fixed revisions. Review conclusions record `actor` and `source`; this skill does not implement approval permissions.
- PRD YAML owns testable, filterable, traceable, and gate-relevant fields. Markdown generated blocks are read-only; human narrative stays outside them.
- Do not auto-commit Git changes. Report changed files and leave commit/push decisions to the user or an explicitly authorized workflow.
- Do not invent RR or Yunlong production contracts. Use `sync mock` until actual platform documentation is supplied.

## Mutation discipline

Inspect the relevant objects and relations before changing them. Create the smallest coherent update, preserve human-authored Markdown, and return object IDs, revisions, changed paths, warnings, and remaining broken links. If validation fails, fix only files in scope; do not weaken schemas or relation rules to make invalid data pass.

For PRD rendering, never use `--force-generated` unless the user explicitly authorizes discarding manual edits inside a generated block.
