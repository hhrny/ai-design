# PRD ownership

Use YAML as the structured source of truth and Markdown as a mixed rendered/narrative view.

## YAML-owned fields

Metadata, features, requirement IDs, priority, scope, exclusions, actors, triggers, preconditions, normative behavior, business rules, acceptance criteria, NFR targets, dependencies, constraints, relations, external references, review references, and baseline references.

## Human Markdown fields

Background, problem narrative, research summary, user journey, rationale, trade-offs, rejected alternatives, UX explanation, screenshots, examples, rollout notes, operational guidance, FAQ, and reading guidance.

## Generated blocks

The renderer owns metadata, feature/requirement tables, business rules, acceptance criteria, NFRs, traceability, external identifiers, review summary, and baseline summary. Generated start markers carry a checksum. If current generated content no longer matches that checksum, stop rather than overwrite it. `--force-generated` is destructive to edits inside generated blocks and requires explicit user authorization.

Rule of thumb: if content must be tested, filtered, counted, linked, or used as a gate, put it in YAML. If it explains why or provides narrative context, put it in the human Markdown area. Promote newly normative prose into structured YAML and reference its ID from Markdown.
