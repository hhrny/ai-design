# Domain model

## Object envelope

Every object has `apiVersion`, `kind`, `metadata`, and `spec`. Metadata contains the stable 19-digit ID, project ID, title, revision, schema version, lifecycle status, owner, timestamps, and canonical content hash.

The CLI supports these MVP kinds: `RequirementAnalysis`, `SolutionDesign`, `PRD`, `Review`, `RequirementItem`, and `Baseline`.

`RequirementItem.spec.requirementType` distinguishes RR, IR, SR, and US. External platform numbers remain separate references.

## ID and revision

Generate IDs as UTC `YYYYMMDDHHmmssRRRRR`. The random portion spans `00000` through `99999`; check all existing object and relation IDs and retry on collision.

An update must carry the current expected revision. A meaningful spec or controlled metadata change increments revision and recomputes the content hash. Timestamps, revision, and the hash itself do not contribute to the canonical content hash.

## Relations

Relation direction is always literal:

- `DERIVED_FROM`: derived source points to its origin target, such as `SolutionDesign -> RequirementAnalysis`.
- `DECOMPOSED_INTO`: an upstream PRD/RR/IR points to the downstream IR/SR/US.
- `SATISFIES`: an implementation or downstream requirement points to the requirement it satisfies.
- `CONSTRAINS`: the constraint source points to the object it constrains.
- `SUPPORTS`: the supporting source points to its supported target.
- `REFERENCES`: non-controlling reference.
- `REVIEWED_BY`: reviewed object points to its Review.
- `BASELINED_BY`: fixed object points to its Baseline.
- `SUPERSEDES`: new object or revision points to the superseded target.

Do not use relations for workflow sequencing when a gate expresses the rule more clearly.

## States

Keep lifecycle, review outcome, workflow progress, and sync state separate. The CLI validates schemas and transition preconditions but does not implement role or approval permissions. Record the caller-provided actor and source for audit.

## Baselines

A baseline fixes object IDs, revisions, content hashes, included relations, schema registry hash, and the current Git commit. Baselines are immutable; create a new baseline to supersede an old one.
