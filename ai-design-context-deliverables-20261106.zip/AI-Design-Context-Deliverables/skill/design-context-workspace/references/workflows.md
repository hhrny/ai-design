# Workflow modes

## Requirement analysis

Capture scenarios, requirements, assumptions, constraints, and open questions in `RequirementAnalysis.spec`. Promote testable statements to structured entries with stable IDs. Link source artifacts with `REFERENCES` or `DERIVED_FROM` as appropriate.

## Solution design

Create `SolutionDesign` from a fixed RequirementAnalysis revision. Store architecture, interfaces, data, security, NFRs, and decisions in the structured spec; keep diagrams and long rationale as artifacts. Use `SolutionDesign DERIVED_FROM RequirementAnalysis`.

## PRD

Create a PRD from the approved solution input, then render its Markdown view. PRD and original RR registration may progress independently. Read `prd-ownership.md` before editing or rendering.

## Review

Start a Review against a fixed object revision. Add findings, resolve them with evidence, then record the outcome supplied by the surrounding process. This skill records, but does not authorize, the outcome.

## Requirement decomposition

Begin only when the PRD state is Approved and the RR ExternalReference is Synced with a non-empty external ID. Create IR/SR/US as `RequirementItem` objects and connect them using `DECOMPOSED_INTO`, `SUPPORTS`, `SATISFIES`, or `CONSTRAINS` according to literal semantics.

After decomposition, external registration and number backfill are a separate sync stage. Backfill changes metadata/references, not approved PRD business content.

## Baseline and delivery

Create a baseline only after validation passes and the index is fresh. Verify the baseline before handoff. A changed current object does not rewrite an older baseline.
