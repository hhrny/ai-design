# CLI reference

All commands accept `--root <workspace>` before the command and emit JSON.

```text
init --name NAME [--project-id ID]
validate
object create --kind KIND --title TITLE --spec-file FILE [--status STATUS] [--owner OWNER]
object show OBJECT_ID
object update OBJECT_ID --expected-revision N --patch-file FILE
relation add --source ID --predicate PREDICATE --target ID
relation check
index rebuild
index status
trace OBJECT_ID [--direction upstream|downstream|both] [--max-depth N]
prd render PRD_ID [--force-generated]
review start --subject ID [--actor TEXT] [--source TEXT]
review finding-add REVIEW_ID --expected-revision N --severity LEVEL --description TEXT
review finding-resolve REVIEW_ID --expected-revision N --finding-id ID --resolution TEXT
review decide REVIEW_ID --expected-revision N --outcome OUTCOME [--actor TEXT] [--source TEXT]
baseline create --baseline-type TYPE --object ID [--object ID ...]
baseline verify BASELINE_ID
decomposition check --prd PRD_ID --rr RR_ID
decomposition create --prd PRD_ID --rr RR_ID --item-type IR|SR|US --title TITLE --statement TEXT
sync mock --object ID --platform NAME --external-type TYPE --outcome OUTCOME [--external-id ID]
```

Exit codes: 0 success; 2 invalid input/schema; 3 state or gate failure; 4 revision conflict; 5 retryable external failure; 6 permanent external failure; 7 workspace/index failure.

The CLI never commits Git changes.
