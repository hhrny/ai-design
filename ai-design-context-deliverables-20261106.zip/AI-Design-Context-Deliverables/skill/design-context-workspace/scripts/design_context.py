#!/usr/bin/env python3
"""Git-backed design context workspace CLI."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import random
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import jsonschema
import yaml


SKILL_DIR = Path(__file__).resolve().parent.parent
ASSET_REGISTRY = SKILL_DIR / "assets" / "schema-registry"
OBJECT_DIRS = {
    "RequirementAnalysis": "requirement-analysis",
    "SolutionDesign": "solution-design",
    "PRD": "prd",
    "Review": "reviews",
    "RequirementItem": "requirement-items",
    "Baseline": "baselines",
}
ID_RE = re.compile(r"^[0-9]{19}$")


class CliError(Exception):
    def __init__(self, code: str, message: str, exit_code: int = 2, details: Any = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.exit_code = exit_code
        self.details = details


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def load_yaml(path: Path) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return yaml.safe_load(handle)
    except FileNotFoundError as exc:
        raise CliError("FILE_NOT_FOUND", f"File not found: {path}") from exc
    except yaml.YAMLError as exc:
        raise CliError("INVALID_YAML", f"Invalid YAML: {path}", details=str(exc)) from exc


def load_data(path: Path) -> Any:
    if path.suffix.lower() == ".json":
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise CliError("INVALID_JSON", f"Invalid JSON: {path}", details=str(exc)) from exc
    return load_yaml(path)


def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_name, path)
    finally:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)


def atomic_write_yaml(path: Path, data: Any) -> None:
    atomic_write_text(path, yaml.safe_dump(data, allow_unicode=True, sort_keys=False))


def append_audit(root: Path, event: dict[str, Any]) -> None:
    path = root / "audit" / "events.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    event = {"timestamp": utc_now(), **event}
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_hash(obj: dict[str, Any]) -> str:
    value = copy.deepcopy(obj)
    metadata = value.get("metadata", {})
    for key in ("revision", "createdAt", "updatedAt", "contentHash"):
        metadata.pop(key, None)
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"sha256:{sha256_bytes(raw)}"


def schema_registry(root: Path) -> dict[str, Any]:
    path = root / "schemas" / "registry.json"
    data = load_data(path)
    if not isinstance(data, dict):
        raise CliError("INVALID_SCHEMA_REGISTRY", f"Schema registry must be an object: {path}")
    return data


def relation_registry(root: Path) -> dict[str, Any]:
    data = load_yaml(root / "schemas" / "relation-types.yaml")
    if not isinstance(data, dict):
        raise CliError("INVALID_RELATION_REGISTRY", "Relation registry must be an object")
    return data


def require_workspace(root: Path) -> dict[str, Any]:
    path = root / "workspace.yaml"
    if not path.exists():
        raise CliError("WORKSPACE_NOT_FOUND", f"No workspace.yaml under {root}", 7)
    data = load_yaml(path)
    if not isinstance(data, dict) or not data.get("projectId"):
        raise CliError("INVALID_WORKSPACE", "workspace.yaml must contain projectId", 7)
    return data


def iter_yaml_files(path: Path):
    if path.exists():
        yield from sorted(path.rglob("*.yaml"))


def collect_ids(root: Path) -> set[str]:
    result: set[str] = set()
    for folder in ("objects", "relations", "external-references", "sync"):
        for path in iter_yaml_files(root / folder):
            try:
                data = load_yaml(path)
            except CliError:
                continue

            def walk(value: Any) -> None:
                if isinstance(value, dict):
                    for key, child in value.items():
                        if key == "id" and isinstance(child, str) and ID_RE.fullmatch(child):
                            result.add(child)
                        walk(child)
                elif isinstance(value, list):
                    for child in value:
                        walk(child)

            walk(data)
    return result


def generate_id(root: Path) -> str:
    existing = collect_ids(root)
    prefix = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    for _ in range(1000):
        candidate = prefix + f"{random.SystemRandom().randrange(100000):05d}"
        if candidate not in existing:
            return candidate
    raise CliError("ID_SPACE_EXHAUSTED", "Could not allocate a unique ID in the current second", 7)


def object_paths(root: Path):
    yield from iter_yaml_files(root / "objects")
    yield from iter_yaml_files(root / "baselines")


def load_objects(root: Path) -> tuple[dict[str, dict[str, Any]], dict[str, Path]]:
    objects: dict[str, dict[str, Any]] = {}
    paths: dict[str, Path] = {}
    for path in object_paths(root):
        data = load_yaml(path)
        if not isinstance(data, dict) or "metadata" not in data:
            continue
        object_id = str(data.get("metadata", {}).get("id", ""))
        if object_id:
            if object_id in objects:
                raise CliError("DUPLICATE_OBJECT_ID", f"Duplicate object ID: {object_id}", details=[str(paths[object_id]), str(path)])
            objects[object_id] = data
            paths[object_id] = path
    return objects, paths


def find_object(root: Path, object_id: str) -> tuple[dict[str, Any], Path]:
    objects, paths = load_objects(root)
    if object_id not in objects:
        raise CliError("OBJECT_NOT_FOUND", f"Object not found: {object_id}")
    return objects[object_id], paths[object_id]


def validate_object(root: Path, obj: dict[str, Any]) -> list[str]:
    registry = schema_registry(root)
    errors: list[str] = []
    for schema, value, label in (
        (registry["envelope"], obj, "envelope"),
        (registry.get("specs", {}).get(obj.get("kind")), obj.get("spec"), f"{obj.get('kind')}.spec"),
    ):
        if not schema:
            errors.append(f"No schema registered for {label}")
            continue
        validator = jsonschema.Draft202012Validator(schema)
        for error in sorted(validator.iter_errors(value), key=lambda item: list(item.path)):
            location = ".".join(str(part) for part in error.path) or "$"
            errors.append(f"{label}.{location}: {error.message}")
    expected = canonical_hash(obj)
    actual = obj.get("metadata", {}).get("contentHash")
    if actual != expected:
        errors.append(f"metadata.contentHash mismatch: expected {expected}, got {actual}")
    return errors


def all_relations(root: Path) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for path in iter_yaml_files(root / "relations"):
        data = load_yaml(path) or {}
        values = data.get("relations", []) if isinstance(data, dict) else []
        if not isinstance(values, list):
            raise CliError("INVALID_RELATION_FILE", f"relations must be a list: {path}")
        for value in values:
            if isinstance(value, dict):
                result.append(value)
    return result


def all_external_refs(root: Path) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for path in iter_yaml_files(root / "external-references"):
        data = load_yaml(path) or {}
        values = data.get("references", []) if isinstance(data, dict) else []
        if isinstance(values, list):
            result.extend(value for value in values if isinstance(value, dict))
    return result


def validate_workspace(root: Path) -> dict[str, Any]:
    require_workspace(root)
    objects, paths = load_objects(root)
    registry = schema_registry(root)
    relation_types = relation_registry(root).get("predicates", {})
    errors: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    for object_id, obj in objects.items():
        for message in validate_object(root, obj):
            errors.append({"path": str(paths[object_id]), "objectId": object_id, "message": message})
    relation_ids: set[str] = set()
    for relation in all_relations(root):
        relation_id = str(relation.get("id", ""))
        for error in jsonschema.Draft202012Validator(registry["relation"]).iter_errors(relation):
            errors.append({"relationId": relation_id, "message": error.message})
        if relation_id in relation_ids:
            errors.append({"relationId": relation_id, "message": "Duplicate relation ID"})
        relation_ids.add(relation_id)
        source_id, target_id = relation.get("sourceId"), relation.get("targetId")
        if source_id not in objects or target_id not in objects:
            errors.append({"relationId": relation_id, "message": "Relation endpoint not found", "sourceId": source_id, "targetId": target_id})
            continue
        predicate = relation.get("predicate")
        rule = relation_types.get(predicate)
        if not rule:
            errors.append({"relationId": relation_id, "message": f"Unknown predicate: {predicate}"})
            continue
        source_kind, target_kind = objects[source_id]["kind"], objects[target_id]["kind"]
        if "*" not in rule.get("sourceKinds", []) and source_kind not in rule.get("sourceKinds", []):
            errors.append({"relationId": relation_id, "message": f"{source_kind} cannot be source of {predicate}"})
        if "*" not in rule.get("targetKinds", []) and target_kind not in rule.get("targetKinds", []):
            errors.append({"relationId": relation_id, "message": f"{target_kind} cannot be target of {predicate}"})
    for ref in all_external_refs(root):
        ref_id = str(ref.get("id", ""))
        for error in jsonschema.Draft202012Validator(registry["externalReference"]).iter_errors(ref):
            errors.append({"externalReferenceId": ref_id, "message": error.message})
        if ref.get("objectId") not in objects:
            errors.append({"externalReferenceId": ref_id, "message": "Referenced object not found"})
    return {"errors": errors, "warnings": warnings, "counts": {"objects": len(objects), "relations": len(relation_ids), "externalReferences": len(all_external_refs(root))}}


def deep_merge(base: Any, patch: Any) -> Any:
    if not isinstance(base, dict) or not isinstance(patch, dict):
        return copy.deepcopy(patch)
    result = copy.deepcopy(base)
    for key, value in patch.items():
        if value is None:
            result.pop(key, None)
        else:
            result[key] = deep_merge(result.get(key), value)
    return result


def object_path(root: Path, kind: str, object_id: str) -> Path:
    folder = OBJECT_DIRS.get(kind)
    if not folder:
        raise CliError("UNSUPPORTED_KIND", f"Unsupported kind: {kind}")
    base = (root / "baselines") if kind == "Baseline" else (root / "objects" / folder)
    return base / f"{object_id}.yaml"


def create_object(root: Path, kind: str, title: str, spec: dict[str, Any], status: str, owner: str | None, actor: str = "cli") -> dict[str, Any]:
    workspace = require_workspace(root)
    object_id = generate_id(root)
    now = utc_now()
    obj = {
        "apiVersion": "design.context/v1",
        "kind": kind,
        "metadata": {
            "id": object_id,
            "projectId": workspace["projectId"],
            "title": title,
            "revision": 1,
            "schemaVersion": "1.0.0",
            "lifecycleStatus": status,
            "owner": owner,
            "createdAt": now,
            "updatedAt": now,
            "contentHash": "",
        },
        "spec": spec,
    }
    obj["metadata"]["contentHash"] = canonical_hash(obj)
    errors = validate_object(root, obj)
    if errors:
        raise CliError("SCHEMA_VALIDATION_FAILED", "Object validation failed", details=errors)
    path = object_path(root, kind, object_id)
    atomic_write_yaml(path, obj)
    append_audit(root, {"event": "object.created", "actor": actor, "objectId": object_id, "revision": 1, "path": str(path.relative_to(root))})
    return {"object": obj, "path": str(path)}


def update_object(root: Path, object_id: str, expected_revision: int, patch: dict[str, Any], actor: str = "cli") -> dict[str, Any]:
    current, path = find_object(root, object_id)
    actual = int(current["metadata"]["revision"])
    if actual != expected_revision:
        raise CliError("REVISION_CONFLICT", f"Expected revision {expected_revision}, current revision is {actual}", 4, {"expected": expected_revision, "actual": actual})
    protected = {key: current["metadata"].get(key) for key in ("id", "projectId", "createdAt")}
    candidate = deep_merge(current, patch)
    candidate["apiVersion"] = current["apiVersion"]
    candidate["kind"] = current["kind"]
    candidate.setdefault("metadata", {})
    candidate["metadata"].update(protected)
    candidate["metadata"]["revision"] = actual + 1
    candidate["metadata"]["updatedAt"] = utc_now()
    candidate["metadata"]["contentHash"] = ""
    candidate["metadata"]["contentHash"] = canonical_hash(candidate)
    if candidate["metadata"]["contentHash"] == current["metadata"]["contentHash"]:
        return {"object": current, "path": str(path), "noChange": True}
    errors = validate_object(root, candidate)
    if errors:
        raise CliError("SCHEMA_VALIDATION_FAILED", "Object validation failed", details=errors)
    atomic_write_yaml(path, candidate)
    append_audit(root, {"event": "object.updated", "actor": actor, "objectId": object_id, "fromRevision": actual, "toRevision": actual + 1, "beforeHash": current["metadata"]["contentHash"], "afterHash": candidate["metadata"]["contentHash"]})
    return {"object": candidate, "path": str(path), "noChange": False}


def git_sha(root: Path) -> str:
    try:
        return subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], text=True, stderr=subprocess.DEVNULL).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return "UNCOMMITTED"


def registry_hash(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted((root / "schemas").glob("*")):
        if path.is_file():
            digest.update(path.name.encode())
            digest.update(path.read_bytes())
    return f"sha256:{digest.hexdigest()}"


def source_hash(root: Path) -> str:
    digest = hashlib.sha256()
    for folder in ("schemas", "objects", "relations", "external-references", "baselines"):
        for path in iter_yaml_files(root / folder):
            digest.update(str(path.relative_to(root)).encode())
            digest.update(path.read_bytes())
        for path in sorted((root / folder).rglob("*.json")) if (root / folder).exists() else []:
            digest.update(str(path.relative_to(root)).encode())
            digest.update(path.read_bytes())
    return f"sha256:{digest.hexdigest()}"


def rebuild_index(root: Path) -> dict[str, Any]:
    report = validate_workspace(root)
    if report["errors"]:
        raise CliError("WORKSPACE_INVALID", "Cannot index an invalid workspace", 7, report["errors"])
    objects, paths = load_objects(root)
    workspace_dir = root / ".workspace"
    workspace_dir.mkdir(parents=True, exist_ok=True)
    tmp = workspace_dir / "index.db.tmp"
    final = workspace_dir / "index.db"
    if tmp.exists():
        tmp.unlink()
    conn = sqlite3.connect(tmp)
    try:
        conn.executescript("""
        PRAGMA foreign_keys=ON;
        CREATE TABLE index_meta(commit_sha TEXT, source_hash TEXT, schema_registry_hash TEXT, built_at TEXT, index_version INTEGER);
        CREATE TABLE objects(id TEXT PRIMARY KEY, kind TEXT, project_id TEXT, revision INTEGER, status TEXT, title TEXT, content_hash TEXT, source_path TEXT);
        CREATE TABLE object_content(object_id TEXT PRIMARY KEY, normalized_json TEXT, FOREIGN KEY(object_id) REFERENCES objects(id));
        CREATE TABLE relations(id TEXT PRIMARY KEY, source_id TEXT, predicate TEXT, target_id TEXT, status TEXT);
        CREATE TABLE external_refs(id TEXT PRIMARY KEY, object_id TEXT, platform TEXT, external_type TEXT, external_id TEXT, sync_status TEXT);
        CREATE TABLE reviews(id TEXT PRIMARY KEY, subject_id TEXT, subject_revision INTEGER, outcome TEXT, status TEXT);
        CREATE TABLE review_findings(id TEXT PRIMARY KEY, review_id TEXT, severity TEXT, status TEXT, owner TEXT);
        CREATE TABLE baselines(id TEXT PRIMARY KEY, baseline_type TEXT, git_commit_sha TEXT, created_at TEXT);
        CREATE TABLE baseline_items(baseline_id TEXT, item_id TEXT, revision INTEGER, content_hash TEXT, PRIMARY KEY(baseline_id,item_id));
        CREATE INDEX idx_rel_source ON relations(source_id,predicate);
        CREATE INDEX idx_rel_target ON relations(target_id,predicate);
        """)
        for object_id, obj in objects.items():
            meta = obj["metadata"]
            conn.execute("INSERT INTO objects VALUES (?,?,?,?,?,?,?,?)", (object_id, obj["kind"], meta["projectId"], meta["revision"], meta["lifecycleStatus"], meta["title"], meta["contentHash"], str(paths[object_id].relative_to(root))))
            conn.execute("INSERT INTO object_content VALUES (?,?)", (object_id, json.dumps(obj["spec"], ensure_ascii=False, sort_keys=True)))
            if obj["kind"] == "Review":
                subject = obj["spec"].get("subject", {})
                decision = obj["spec"].get("decision") or {}
                conn.execute("INSERT INTO reviews VALUES (?,?,?,?,?)", (object_id, subject.get("objectId"), subject.get("revision"), decision.get("outcome"), meta["lifecycleStatus"]))
                for finding in obj["spec"].get("findings", []):
                    conn.execute("INSERT INTO review_findings VALUES (?,?,?,?,?)", (finding.get("id"), object_id, finding.get("severity"), finding.get("status"), finding.get("owner")))
            if obj["kind"] == "Baseline":
                conn.execute("INSERT INTO baselines VALUES (?,?,?,?)", (object_id, obj["spec"].get("baselineType"), obj["spec"].get("gitCommitSha"), meta["createdAt"]))
                for item in obj["spec"].get("items", []):
                    conn.execute("INSERT INTO baseline_items VALUES (?,?,?,?)", (object_id, item.get("objectId"), item.get("revision"), item.get("contentHash")))
        for relation in all_relations(root):
            conn.execute("INSERT INTO relations VALUES (?,?,?,?,?)", (relation["id"], relation["sourceId"], relation["predicate"], relation["targetId"], relation["status"]))
        for ref in all_external_refs(root):
            conn.execute("INSERT INTO external_refs VALUES (?,?,?,?,?,?)", (ref["id"], ref["objectId"], ref["platform"], ref["externalType"], ref.get("externalId"), ref["syncStatus"]))
        conn.execute("INSERT INTO index_meta VALUES (?,?,?,?,?)", (git_sha(root), source_hash(root), registry_hash(root), utc_now(), 1))
        integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise CliError("INDEX_INTEGRITY_FAILED", integrity, 7)
        conn.commit()
    finally:
        conn.close()
    os.replace(tmp, final)
    return {"path": str(final), "commitSha": git_sha(root), "sourceHash": source_hash(root), **report["counts"]}


def index_status(root: Path) -> dict[str, Any]:
    path = root / ".workspace" / "index.db"
    if not path.exists():
        return {"status": "Missing", "path": str(path)}
    try:
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        row = conn.execute("SELECT commit_sha,source_hash,schema_registry_hash,built_at,index_version FROM index_meta").fetchone()
        conn.close()
    except sqlite3.Error as exc:
        return {"status": "Invalid", "path": str(path), "error": str(exc)}
    current_source = source_hash(root)
    status = "Fresh" if row and row[1] == current_source and row[2] == registry_hash(root) else "Stale"
    return {"status": status, "path": str(path), "indexedCommitSha": row[0], "currentCommitSha": git_sha(root), "indexedSourceHash": row[1], "currentSourceHash": current_source, "builtAt": row[3], "indexVersion": row[4]}


def add_relation(root: Path, source_id: str, predicate: str, target_id: str, actor: str) -> dict[str, Any]:
    objects, _ = load_objects(root)
    if source_id not in objects or target_id not in objects:
        raise CliError("RELATION_ENDPOINT_NOT_FOUND", "Both relation endpoints must exist")
    rule = relation_registry(root).get("predicates", {}).get(predicate)
    if not rule:
        raise CliError("UNKNOWN_PREDICATE", f"Unknown predicate: {predicate}")
    source_kind, target_kind = objects[source_id]["kind"], objects[target_id]["kind"]
    if "*" not in rule["sourceKinds"] and source_kind not in rule["sourceKinds"]:
        raise CliError("RELATION_TYPE_INVALID", f"{source_kind} cannot be source of {predicate}")
    if "*" not in rule["targetKinds"] and target_kind not in rule["targetKinds"]:
        raise CliError("RELATION_TYPE_INVALID", f"{target_kind} cannot be target of {predicate}")
    for existing in all_relations(root):
        if existing.get("sourceId") == source_id and existing.get("predicate") == predicate and existing.get("targetId") == target_id and existing.get("status") == "Active":
            return {"relation": existing, "noChange": True}
    relation = {"id": generate_id(root), "sourceId": source_id, "predicate": predicate, "targetId": target_id, "status": "Active", "createdAt": utc_now(), "createdBy": actor}
    path = root / "relations" / f"{source_id}.yaml"
    data = load_yaml(path) if path.exists() else {"relations": []}
    data.setdefault("relations", []).append(relation)
    atomic_write_yaml(path, data)
    append_audit(root, {"event": "relation.added", "actor": actor, "relationId": relation["id"], "sourceId": source_id, "predicate": predicate, "targetId": target_id})
    return {"relation": relation, "path": str(path), "noChange": False}


def trace_object(root: Path, object_id: str, direction: str, max_depth: int) -> dict[str, Any]:
    status = index_status(root)
    if status["status"] != "Fresh":
        raise CliError("INDEX_NOT_FRESH", f"Index status is {status['status']}; rebuild it before tracing", 7, status)
    db = root / ".workspace" / "index.db"
    conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    if not conn.execute("SELECT 1 FROM objects WHERE id=?", (object_id,)).fetchone():
        conn.close()
        raise CliError("OBJECT_NOT_FOUND", f"Object not found: {object_id}")
    queue = deque([(object_id, 0)])
    seen = {object_id}
    edges: list[dict[str, Any]] = []
    target_is_upstream = {"DERIVED_FROM", "SATISFIES", "SUPPORTS", "SUPERSEDES"}
    target_is_downstream = {"DECOMPOSED_INTO", "CONSTRAINS", "REVIEWED_BY", "BASELINED_BY"}
    while queue:
        current, depth = queue.popleft()
        if depth >= max_depth:
            continue
        candidates = [(row[0], row[1], row[2]) for row in conn.execute("SELECT source_id,predicate,target_id FROM relations WHERE (source_id=? OR target_id=?) AND status='Active'", (current, current))]
        for source, predicate, target in candidates:
            if predicate in target_is_upstream:
                edge_direction = "upstream" if current == source else "downstream"
            elif predicate in target_is_downstream:
                edge_direction = "downstream" if current == source else "upstream"
            else:
                edge_direction = "both"
            if direction != "both" and edge_direction not in (direction, "both"):
                continue
            edge = {"sourceId": source, "predicate": predicate, "targetId": target}
            if edge not in edges:
                edges.append(edge)
            neighbor = target if source == current else source
            if neighbor not in seen:
                seen.add(neighbor)
                queue.append((neighbor, depth + 1))
    nodes = []
    for node_id in sorted(seen):
        row = conn.execute("SELECT id,kind,title,revision,status FROM objects WHERE id=?", (node_id,)).fetchone()
        if row:
            nodes.append({"id": row[0], "kind": row[1], "title": row[2], "revision": row[3], "status": row[4]})
    conn.close()
    return {"rootObjectId": object_id, "direction": direction, "nodes": nodes, "edges": edges}


def md_table(headers: list[str], rows: list[list[Any]]) -> str:
    def cell(value: Any) -> str:
        return str(value if value is not None else "").replace("|", "\\|").replace("\n", " ")
    return "\n".join(["| " + " | ".join(map(cell, headers)) + " |", "|" + "|".join(["---"] * len(headers)) + "|"] + ["| " + " | ".join(cell(value) for value in row) + " |" for row in rows])


def generated_block(name: str, content: str) -> str:
    content = content.strip()
    digest = sha256_bytes(content.encode("utf-8"))
    return f"<!-- GENERATED:{name} START sha256={digest} -->\n{content}\n<!-- GENERATED:{name} END -->"


def replace_generated(existing: str, name: str, replacement: str, force: bool) -> str:
    pattern = re.compile(rf"<!-- GENERATED:{re.escape(name)} START sha256=([0-9a-f]{{64}}) -->\n(.*?)\n<!-- GENERATED:{re.escape(name)} END -->", re.DOTALL)
    match = pattern.search(existing)
    if not match:
        return existing.rstrip() + "\n\n" + replacement + "\n"
    actual = sha256_bytes(match.group(2).encode("utf-8"))
    if actual != match.group(1) and not force:
        raise CliError("GENERATED_BLOCK_MODIFIED", f"Generated block {name} was manually modified; refusing to overwrite", 3)
    return existing[:match.start()] + replacement + existing[match.end():]


def render_prd(root: Path, prd_id: str, force: bool) -> dict[str, Any]:
    obj, _ = find_object(root, prd_id)
    if obj["kind"] != "PRD":
        raise CliError("NOT_A_PRD", f"Object {prd_id} is {obj['kind']}, not PRD")
    meta, spec = obj["metadata"], obj["spec"]
    metadata_content = md_table(["Field", "Value"], [["ID", meta["id"]], ["Revision", meta["revision"]], ["Status", meta["lifecycleStatus"]], ["Owner", meta.get("owner", "")], ["Content hash", meta["contentHash"]]])
    requirement_rows = [[item.get("id", ""), item.get("title", item.get("statement", "")), item.get("priority", ""), item.get("status", "")] for item in spec.get("requirements", [])]
    requirements_content = md_table(["ID", "Requirement", "Priority", "Status"], requirement_rows) if requirement_rows else "_No structured requirements._"
    rule_rows = [[item.get("id", ""), item.get("rule", item.get("description", ""))] for item in spec.get("businessRules", [])]
    rules_content = md_table(["ID", "Business rule"], rule_rows) if rule_rows else "_No structured business rules._"
    ac_rows = [[item.get("id", ""), item.get("condition", item.get("description", str(item))), item.get("verification", "")] for item in spec.get("acceptanceCriteria", [])]
    ac_content = md_table(["ID", "Acceptance criterion", "Verification"], ac_rows) if ac_rows else "_No structured acceptance criteria._"
    blocks = {"prd-metadata": generated_block("prd-metadata", metadata_content), "requirements": generated_block("requirements", requirements_content), "business-rules": generated_block("business-rules", rules_content), "acceptance": generated_block("acceptance", ac_content)}
    path = root / "artifacts" / "prd" / prd_id / "PRD.md"
    if path.exists():
        text = path.read_text(encoding="utf-8")
        for name, block in blocks.items():
            text = replace_generated(text, name, block, force)
    else:
        text = f"# {meta['title']}\n\n{blocks['prd-metadata']}\n\n## Background and goals\n\n<!-- HUMAN:background START -->\nAdd product context and rationale here.\n<!-- HUMAN:background END -->\n\n## Structured requirements\n\n{blocks['requirements']}\n\n## Business rules\n\n{blocks['business-rules']}\n\n## Acceptance criteria\n\n{blocks['acceptance']}\n\n## User journey and design rationale\n\n<!-- HUMAN:rationale START -->\nAdd narrative, examples, screenshots, and trade-offs here.\n<!-- HUMAN:rationale END -->\n"
    atomic_write_text(path, text)
    append_audit(root, {"event": "prd.rendered", "objectId": prd_id, "revision": meta["revision"], "path": str(path.relative_to(root))})
    return {"objectId": prd_id, "revision": meta["revision"], "path": str(path)}


def start_review(root: Path, subject_id: str, actor: str, source: str) -> dict[str, Any]:
    subject, _ = find_object(root, subject_id)
    spec = {"subject": {"objectId": subject_id, "revision": subject["metadata"]["revision"], "contentHash": subject["metadata"]["contentHash"]}, "findings": [], "decision": None, "startedBy": {"actor": actor, "source": source}}
    return create_object(root, "Review", f"Review: {subject['metadata']['title']}", spec, "InProgress", None, actor)


def review_add_finding(root: Path, review_id: str, expected_revision: int, severity: str, description: str, owner: str | None, actor: str) -> dict[str, Any]:
    review, _ = find_object(root, review_id)
    if review["kind"] != "Review":
        raise CliError("NOT_A_REVIEW", f"Object {review_id} is not a Review")
    findings = copy.deepcopy(review["spec"].get("findings", []))
    finding = {"id": generate_id(root), "severity": severity, "description": description, "owner": owner, "status": "Open", "createdAt": utc_now()}
    findings.append(finding)
    result = update_object(root, review_id, expected_revision, {"spec": {"findings": findings}}, actor)
    result["finding"] = finding
    return result


def review_resolve_finding(root: Path, review_id: str, expected_revision: int, finding_id: str, resolution: str, actor: str) -> dict[str, Any]:
    review, _ = find_object(root, review_id)
    findings = copy.deepcopy(review["spec"].get("findings", []))
    found = False
    for finding in findings:
        if finding.get("id") == finding_id:
            finding.update({"status": "Resolved", "resolution": resolution, "resolvedAt": utc_now(), "resolvedBy": actor})
            found = True
    if not found:
        raise CliError("FINDING_NOT_FOUND", f"Finding not found: {finding_id}")
    return update_object(root, review_id, expected_revision, {"spec": {"findings": findings}}, actor)


def review_decide(root: Path, review_id: str, expected_revision: int, outcome: str, actor: str, source: str, rationale: str) -> dict[str, Any]:
    review, _ = find_object(root, review_id)
    if review["spec"].get("decision"):
        raise CliError("REVIEW_ALREADY_DECIDED", "Review decision is immutable; create a new Review to supersede it", 3)
    if outcome in ("Passed", "PassedWithActions"):
        blocking = [item for item in review["spec"].get("findings", []) if item.get("severity") in ("Critical", "High") and item.get("status") != "Resolved"]
        if blocking:
            raise CliError("BLOCKING_FINDINGS_OPEN", "Critical or High findings remain open", 3, [item.get("id") for item in blocking])
    decision = {"outcome": outcome, "actor": actor, "source": source, "rationale": rationale, "decidedAt": utc_now()}
    return update_object(root, review_id, expected_revision, {"metadata": {"lifecycleStatus": "Completed"}, "spec": {"decision": decision}}, actor)


def create_baseline(root: Path, baseline_type: str, object_ids: list[str], actor: str) -> dict[str, Any]:
    objects, _ = load_objects(root)
    missing = [value for value in object_ids if value not in objects]
    if missing:
        raise CliError("OBJECT_NOT_FOUND", "Baseline object not found", details=missing)
    items = [{"objectId": value, "revision": objects[value]["metadata"]["revision"], "contentHash": objects[value]["metadata"]["contentHash"], "kind": objects[value]["kind"]} for value in object_ids]
    selected = set(object_ids)
    relations = [relation for relation in all_relations(root) if relation.get("sourceId") in selected and relation.get("targetId") in selected]
    spec = {"baselineType": baseline_type, "gitCommitSha": git_sha(root), "schemaRegistryHash": registry_hash(root), "items": items, "relations": relations}
    return create_object(root, "Baseline", f"{baseline_type} baseline", spec, "Confirmed", None, actor)


def verify_baseline(root: Path, baseline_id: str) -> dict[str, Any]:
    baseline, _ = find_object(root, baseline_id)
    if baseline["kind"] != "Baseline":
        raise CliError("NOT_A_BASELINE", f"Object {baseline_id} is not a Baseline")
    objects, _ = load_objects(root)
    results = []
    for item in baseline["spec"]["items"]:
        current = objects.get(item["objectId"])
        state = "Missing" if not current else ("Valid" if current["metadata"]["revision"] == item["revision"] and current["metadata"]["contentHash"] == item["contentHash"] else "Changed")
        results.append({"objectId": item["objectId"], "state": state})
    commit_match = baseline["spec"]["gitCommitSha"] == git_sha(root)
    registry_match = baseline["spec"]["schemaRegistryHash"] == registry_hash(root)
    valid = all(item["state"] == "Valid" for item in results) and commit_match and registry_match
    return {"baselineId": baseline_id, "valid": valid, "items": results, "gitCommitMatch": commit_match, "schemaRegistryMatch": registry_match}


def decomposition_gate(root: Path, prd_id: str, rr_id: str, enforce: bool = True) -> dict[str, Any]:
    prd, _ = find_object(root, prd_id)
    rr, _ = find_object(root, rr_id)
    if prd["kind"] != "PRD":
        raise CliError("NOT_A_PRD", f"Object {prd_id} is not a PRD")
    if rr["kind"] != "RequirementItem" or rr.get("spec", {}).get("requirementType") != "RR":
        raise CliError("NOT_AN_RR", f"Object {rr_id} is not an RR RequirementItem")
    objects, _ = load_objects(root)
    matching_reviews = []
    for obj in objects.values():
        if obj.get("kind") != "Review":
            continue
        subject = obj.get("spec", {}).get("subject", {})
        decision = obj.get("spec", {}).get("decision") or {}
        blocking = [item for item in obj.get("spec", {}).get("findings", []) if item.get("severity") in ("Critical", "High") and item.get("status") != "Resolved"]
        if subject.get("objectId") == prd_id and subject.get("revision") == prd["metadata"]["revision"] and decision.get("outcome") in ("Passed", "PassedWithActions") and not blocking:
            matching_reviews.append(obj["metadata"]["id"])
    rr_refs = [ref for ref in all_external_refs(root) if ref.get("objectId") == rr_id and ref.get("externalType") == "RR" and ref.get("syncStatus") == "Synced" and ref.get("externalId")]
    conditions = {
        "prdApproved": prd["metadata"].get("lifecycleStatus") == "Approved",
        "prdReviewPassed": bool(matching_reviews),
        "rrSynced": bool(rr_refs),
        "rrExternalIdPresent": bool(rr_refs and rr_refs[0].get("externalId")),
    }
    result = {"ready": all(conditions.values()), "prdId": prd_id, "rrId": rr_id, "conditions": conditions, "reviewIds": matching_reviews, "rrExternalReferenceIds": [ref["id"] for ref in rr_refs]}
    if enforce and not result["ready"]:
        raise CliError("DECOMPOSITION_GATE_NOT_SATISFIED", "Demand decomposition gate is not satisfied", 3, result)
    return result


def create_decomposition_item(root: Path, prd_id: str, rr_id: str, item_type: str, title: str, statement: str, owner: str | None, actor: str) -> dict[str, Any]:
    gate = decomposition_gate(root, prd_id, rr_id, True)
    created = create_object(root, "RequirementItem", title, {"requirementType": item_type, "statement": statement, "acceptanceCriteria": []}, "Draft", owner, actor)
    item_id = created["object"]["metadata"]["id"]
    relations = [
        add_relation(root, prd_id, "DECOMPOSED_INTO", item_id, actor)["relation"],
        add_relation(root, rr_id, "DECOMPOSED_INTO", item_id, actor)["relation"],
    ]
    return {"object": created["object"], "path": created["path"], "relations": relations, "gate": gate}


def mock_sync(root: Path, object_id: str, platform: str, external_type: str, outcome: str, external_id: str | None, actor: str, idempotency_key: str | None) -> dict[str, Any]:
    obj, _ = find_object(root, object_id)
    key = idempotency_key or sha256_bytes(f"{object_id}:{platform}:{external_type}:{obj['metadata']['contentHash']}".encode())
    for path in iter_yaml_files(root / "sync" / "attempts"):
        attempt = load_yaml(path)
        if attempt.get("idempotencyKey") == key and attempt.get("outcome") == "success":
            return {"attempt": attempt, "idempotentReplay": True}
    attempt_id = generate_id(root)
    status_map = {"success": "Synced", "partial": "PartiallyCompleted", "timeout": "SyncFailed", "retryable": "SyncFailed", "permanent": "SyncFailed"}
    attempt = {"id": attempt_id, "objectId": object_id, "platform": platform, "externalType": external_type, "idempotencyKey": key, "outcome": outcome, "syncStatus": status_map[outcome], "actor": actor, "startedAt": utc_now(), "completedAt": utc_now()}
    attempt_path = root / "sync" / "attempts" / f"{attempt_id}.yaml"
    atomic_write_yaml(attempt_path, attempt)
    result: dict[str, Any] = {"attempt": attempt, "path": str(attempt_path)}
    if outcome in ("success", "partial"):
        ref_id = generate_id(root)
        reference = {"id": ref_id, "objectId": object_id, "platform": platform, "externalType": external_type, "externalId": external_id or f"SIM-{object_id[-8:]}", "externalUrl": None, "syncStatus": status_map[outcome], "lastSuccessfulAttemptId": attempt_id if outcome == "success" else None}
        ref_path = root / "external-references" / f"{object_id}.yaml"
        data = load_yaml(ref_path) if ref_path.exists() else {"references": []}
        existing = [item for item in data["references"] if item.get("platform") == platform and item.get("externalType") == external_type]
        if existing:
            existing[0].update(reference)
            reference = existing[0]
        else:
            data["references"].append(reference)
        atomic_write_yaml(ref_path, data)
        result["externalReference"] = reference
    append_audit(root, {"event": "sync.mock", "actor": actor, "objectId": object_id, "attemptId": attempt_id, "outcome": outcome})
    if outcome in ("timeout", "retryable"):
        raise CliError("EXTERNAL_RETRYABLE", f"Mock sync outcome: {outcome}", 5, result)
    if outcome == "permanent":
        raise CliError("EXTERNAL_PERMANENT", "Mock sync permanent failure", 6, result)
    return result


def init_workspace(root: Path, name: str, project_id: str | None) -> dict[str, Any]:
    if (root / "workspace.yaml").exists():
        raise CliError("WORKSPACE_EXISTS", f"Workspace already exists: {root}", 3)
    root.mkdir(parents=True, exist_ok=True)
    project_id = project_id or re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or generate_id(root)
    for folder in ("objects/requirement-analysis", "objects/solution-design", "objects/prd", "objects/reviews", "objects/requirement-items", "relations", "external-references", "baselines", "artifacts/prd", "sync/attempts", "audit", ".workspace", "schemas"):
        (root / folder).mkdir(parents=True, exist_ok=True)
    shutil.copy2(ASSET_REGISTRY / "registry.json", root / "schemas" / "registry.json")
    shutil.copy2(ASSET_REGISTRY / "relation-types.yaml", root / "schemas" / "relation-types.yaml")
    atomic_write_yaml(root / "workspace.yaml", {"apiVersion": "design.context/v1", "projectId": project_id, "name": name, "createdAt": utc_now()})
    gitignore = root / ".gitignore"
    existing = gitignore.read_text(encoding="utf-8") if gitignore.exists() else ""
    if ".workspace/" not in existing.splitlines():
        atomic_write_text(gitignore, existing.rstrip() + ("\n" if existing.strip() else "") + ".workspace/\n")
    return {"root": str(root), "projectId": project_id, "workspace": str(root / "workspace.yaml")}


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description="Manage a Git-backed design context workspace")
    result.add_argument("--root", required=True, type=Path)
    sub = result.add_subparsers(dest="command", required=True)
    p = sub.add_parser("init"); p.add_argument("--name", required=True); p.add_argument("--project-id")
    sub.add_parser("validate")
    obj = sub.add_parser("object").add_subparsers(dest="object_command", required=True)
    p = obj.add_parser("create"); p.add_argument("--kind", required=True, choices=sorted(OBJECT_DIRS)); p.add_argument("--title", required=True); p.add_argument("--spec-file", required=True, type=Path); p.add_argument("--status", default="Draft"); p.add_argument("--owner"); p.add_argument("--actor", default="cli")
    p = obj.add_parser("show"); p.add_argument("object_id")
    p = obj.add_parser("update"); p.add_argument("object_id"); p.add_argument("--expected-revision", required=True, type=int); p.add_argument("--patch-file", required=True, type=Path); p.add_argument("--actor", default="cli")
    rel = sub.add_parser("relation").add_subparsers(dest="relation_command", required=True)
    p = rel.add_parser("add"); p.add_argument("--source", required=True); p.add_argument("--predicate", required=True); p.add_argument("--target", required=True); p.add_argument("--actor", default="cli")
    rel.add_parser("check")
    idx = sub.add_parser("index").add_subparsers(dest="index_command", required=True); idx.add_parser("rebuild"); idx.add_parser("status")
    p = sub.add_parser("trace"); p.add_argument("object_id"); p.add_argument("--direction", choices=["upstream", "downstream", "both"], default="both"); p.add_argument("--max-depth", type=int, default=8)
    prd = sub.add_parser("prd").add_subparsers(dest="prd_command", required=True); p = prd.add_parser("render"); p.add_argument("prd_id"); p.add_argument("--force-generated", action="store_true")
    review = sub.add_parser("review").add_subparsers(dest="review_command", required=True)
    p = review.add_parser("start"); p.add_argument("--subject", required=True); p.add_argument("--actor", default="cli"); p.add_argument("--source", default="human")
    p = review.add_parser("finding-add"); p.add_argument("review_id"); p.add_argument("--expected-revision", type=int, required=True); p.add_argument("--severity", choices=["Low", "Medium", "High", "Critical"], required=True); p.add_argument("--description", required=True); p.add_argument("--owner"); p.add_argument("--actor", default="cli")
    p = review.add_parser("finding-resolve"); p.add_argument("review_id"); p.add_argument("--expected-revision", type=int, required=True); p.add_argument("--finding-id", required=True); p.add_argument("--resolution", required=True); p.add_argument("--actor", default="cli")
    p = review.add_parser("decide"); p.add_argument("review_id"); p.add_argument("--expected-revision", type=int, required=True); p.add_argument("--outcome", choices=["Passed", "PassedWithActions", "Rework", "Rejected"], required=True); p.add_argument("--actor", default="cli"); p.add_argument("--source", default="human"); p.add_argument("--rationale", default="")
    baseline = sub.add_parser("baseline").add_subparsers(dest="baseline_command", required=True)
    p = baseline.add_parser("create"); p.add_argument("--baseline-type", required=True); p.add_argument("--object", action="append", required=True); p.add_argument("--actor", default="cli")
    p = baseline.add_parser("verify"); p.add_argument("baseline_id")
    decomposition = sub.add_parser("decomposition").add_subparsers(dest="decomposition_command", required=True)
    p = decomposition.add_parser("check"); p.add_argument("--prd", required=True); p.add_argument("--rr", required=True)
    p = decomposition.add_parser("create"); p.add_argument("--prd", required=True); p.add_argument("--rr", required=True); p.add_argument("--item-type", choices=["IR", "SR", "US"], required=True); p.add_argument("--title", required=True); p.add_argument("--statement", required=True); p.add_argument("--owner"); p.add_argument("--actor", default="cli")
    sync = sub.add_parser("sync").add_subparsers(dest="sync_command", required=True)
    p = sync.add_parser("mock"); p.add_argument("--object", required=True); p.add_argument("--platform", required=True); p.add_argument("--external-type", required=True); p.add_argument("--outcome", choices=["success", "partial", "timeout", "retryable", "permanent"], required=True); p.add_argument("--external-id"); p.add_argument("--actor", default="cli"); p.add_argument("--idempotency-key")
    return result


def dispatch(args: argparse.Namespace) -> dict[str, Any]:
    root = args.root.resolve()
    if args.command == "init": return init_workspace(root, args.name, args.project_id)
    require_workspace(root)
    if args.command == "validate":
        report = validate_workspace(root)
        if report["errors"]: raise CliError("WORKSPACE_INVALID", "Workspace validation failed", 2, report)
        return report
    if args.command == "object":
        if args.object_command == "create":
            spec = load_data(args.spec_file.resolve());
            if not isinstance(spec, dict): raise CliError("INVALID_SPEC", "Spec file must contain an object")
            return create_object(root, args.kind, args.title, spec, args.status, args.owner, args.actor)
        if args.object_command == "show":
            obj, path = find_object(root, args.object_id); return {"object": obj, "path": str(path)}
        patch = load_data(args.patch_file.resolve())
        if not isinstance(patch, dict): raise CliError("INVALID_PATCH", "Patch file must contain an object")
        return update_object(root, args.object_id, args.expected_revision, patch, args.actor)
    if args.command == "relation":
        if args.relation_command == "add": return add_relation(root, args.source, args.predicate, args.target, args.actor)
        report = validate_workspace(root)
        relation_errors = [error for error in report["errors"] if "relationId" in error]
        if relation_errors: raise CliError("RELATION_CHECK_FAILED", "Relation check failed", 2, relation_errors)
        return {"relations": report["counts"]["relations"], "errors": []}
    if args.command == "index": return rebuild_index(root) if args.index_command == "rebuild" else index_status(root)
    if args.command == "trace": return trace_object(root, args.object_id, args.direction, args.max_depth)
    if args.command == "prd": return render_prd(root, args.prd_id, args.force_generated)
    if args.command == "review":
        if args.review_command == "start": return start_review(root, args.subject, args.actor, args.source)
        if args.review_command == "finding-add": return review_add_finding(root, args.review_id, args.expected_revision, args.severity, args.description, args.owner, args.actor)
        if args.review_command == "finding-resolve": return review_resolve_finding(root, args.review_id, args.expected_revision, args.finding_id, args.resolution, args.actor)
        return review_decide(root, args.review_id, args.expected_revision, args.outcome, args.actor, args.source, args.rationale)
    if args.command == "baseline": return create_baseline(root, args.baseline_type, args.object, args.actor) if args.baseline_command == "create" else verify_baseline(root, args.baseline_id)
    if args.command == "decomposition": return decomposition_gate(root, args.prd, args.rr, True) if args.decomposition_command == "check" else create_decomposition_item(root, args.prd, args.rr, args.item_type, args.title, args.statement, args.owner, args.actor)
    if args.command == "sync": return mock_sync(root, args.object, args.platform, args.external_type, args.outcome, args.external_id, args.actor, args.idempotency_key)
    raise CliError("UNKNOWN_COMMAND", args.command)


def main() -> int:
    args = parser().parse_args()
    try:
        result = dispatch(args)
        print(json.dumps({"ok": True, "command": args.command, "result": result, "warnings": [], "errors": []}, ensure_ascii=False, indent=2))
        return 0
    except CliError as exc:
        print(json.dumps({"ok": False, "command": getattr(args, "command", None), "result": None, "warnings": [], "errors": [{"code": exc.code, "message": exc.message, "details": exc.details}]}, ensure_ascii=False, indent=2))
        return exc.exit_code
    except Exception as exc:  # pragma: no cover
        print(json.dumps({"ok": False, "command": getattr(args, "command", None), "result": None, "warnings": [], "errors": [{"code": "UNEXPECTED_ERROR", "message": str(exc)}]}, ensure_ascii=False, indent=2))
        return 7


if __name__ == "__main__":
    raise SystemExit(main())
