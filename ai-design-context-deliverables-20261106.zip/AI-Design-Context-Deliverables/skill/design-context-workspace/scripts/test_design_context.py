#!/usr/bin/env python3

import importlib.util
import tempfile
import unittest
from pathlib import Path


MODULE_PATH = Path(__file__).with_name("design_context.py")
SPEC = importlib.util.spec_from_file_location("design_context", MODULE_PATH)
dc = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(dc)


class DesignContextTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "workspace"
        dc.init_workspace(self.root, "Test Workspace", "test-workspace")

    def tearDown(self):
        self.temp.cleanup()

    def test_end_to_end(self):
        analysis = dc.create_object(
            self.root,
            "RequirementAnalysis",
            "Login analysis",
            {"requirements": [{"id": "REQ-1", "statement": "Users can sign in"}]},
            "Confirmed",
            "sa",
        )["object"]
        solution = dc.create_object(
            self.root,
            "SolutionDesign",
            "Login solution",
            {"overview": {"objective": "Secure login"}},
            "Approved",
            "architect",
        )["object"]
        prd = dc.create_object(
            self.root,
            "PRD",
            "Login PRD",
            {
                "requirements": [{"id": "PRD-REQ-1", "title": "Sign in", "priority": "Must", "status": "Confirmed"}],
                "businessRules": [{"id": "BR-1", "rule": "Lock after repeated failures"}],
                "acceptanceCriteria": [{"id": "AC-1", "condition": "Valid credentials", "verification": "Login succeeds"}],
            },
            "Approved",
            "product",
        )["object"]

        relation = dc.add_relation(self.root, solution["metadata"]["id"], "DERIVED_FROM", analysis["metadata"]["id"], "test")
        self.assertFalse(relation["noChange"])
        dc.add_relation(self.root, prd["metadata"]["id"], "DERIVED_FROM", solution["metadata"]["id"], "test")

        render = dc.render_prd(self.root, prd["metadata"]["id"], False)
        rendered_path = Path(render["path"])
        original = rendered_path.read_text(encoding="utf-8")
        rendered_path.write_text(original.replace("Add product context and rationale here.", "Human product context."), encoding="utf-8")
        dc.render_prd(self.root, prd["metadata"]["id"], False)
        self.assertIn("Human product context.", rendered_path.read_text(encoding="utf-8"))

        review = dc.start_review(self.root, solution["metadata"]["id"], "reviewer", "human")["object"]
        added = dc.review_add_finding(self.root, review["metadata"]["id"], 1, "High", "Clarify failure handling", "architect", "reviewer")
        finding_id = added["finding"]["id"]
        with self.assertRaises(dc.CliError) as blocked:
            dc.review_decide(self.root, review["metadata"]["id"], 2, "Passed", "committee", "external", "")
        self.assertEqual(blocked.exception.code, "BLOCKING_FINDINGS_OPEN")
        dc.review_resolve_finding(self.root, review["metadata"]["id"], 2, finding_id, "Documented retry behavior", "architect")
        decided = dc.review_decide(self.root, review["metadata"]["id"], 3, "Passed", "committee", "external", "Accepted")
        self.assertEqual(decided["object"]["spec"]["decision"]["outcome"], "Passed")

        rr = dc.create_object(self.root, "RequirementItem", "Original RR", {"requirementType": "RR", "statement": "Support secure login"}, "Confirmed", "sa")["object"]
        sync = dc.mock_sync(self.root, rr["metadata"]["id"], "RR", "RR", "success", "RR-123", "test", "idem-1")
        self.assertEqual(sync["externalReference"]["externalId"], "RR-123")
        replay = dc.mock_sync(self.root, rr["metadata"]["id"], "RR", "RR", "success", "RR-123", "test", "idem-1")
        self.assertTrue(replay["idempotentReplay"])
        prd_review = dc.start_review(self.root, prd["metadata"]["id"], "reviewer", "external")["object"]
        dc.review_decide(self.root, prd_review["metadata"]["id"], 1, "Passed", "committee", "external", "Accepted")
        self.assertTrue(dc.decomposition_gate(self.root, prd["metadata"]["id"], rr["metadata"]["id"])["ready"])
        ir = dc.create_decomposition_item(self.root, prd["metadata"]["id"], rr["metadata"]["id"], "IR", "Login IR", "Provide user login", "se", "test")
        self.assertEqual(ir["object"]["spec"]["requirementType"], "IR")

        baseline = dc.create_baseline(self.root, "Solution", [analysis["metadata"]["id"], solution["metadata"]["id"], prd["metadata"]["id"]], "test")["object"]
        self.assertTrue(dc.verify_baseline(self.root, baseline["metadata"]["id"])["valid"])

        report = dc.validate_workspace(self.root)
        self.assertEqual(report["errors"], [])
        index = dc.rebuild_index(self.root)
        self.assertEqual(index["objects"], 8)
        self.assertEqual(dc.index_status(self.root)["status"], "Fresh")
        trace = dc.trace_object(self.root, prd["metadata"]["id"], "upstream", 8)
        self.assertEqual(len(trace["nodes"]), 3)

    def test_revision_conflict_and_generated_block_guard(self):
        prd = dc.create_object(self.root, "PRD", "PRD", {"requirements": []}, "Draft", None)["object"]
        object_id = prd["metadata"]["id"]
        dc.update_object(self.root, object_id, 1, {"metadata": {"title": "Changed"}})
        with self.assertRaises(dc.CliError) as conflict:
            dc.update_object(self.root, object_id, 1, {"metadata": {"title": "Lost update"}})
        self.assertEqual(conflict.exception.code, "REVISION_CONFLICT")

        path = Path(dc.render_prd(self.root, object_id, False)["path"])
        text = path.read_text(encoding="utf-8").replace("_No structured requirements._", "Manual generated edit")
        path.write_text(text, encoding="utf-8")
        with self.assertRaises(dc.CliError) as modified:
            dc.render_prd(self.root, object_id, False)
        self.assertEqual(modified.exception.code, "GENERATED_BLOCK_MODIFIED")


if __name__ == "__main__":
    unittest.main()
