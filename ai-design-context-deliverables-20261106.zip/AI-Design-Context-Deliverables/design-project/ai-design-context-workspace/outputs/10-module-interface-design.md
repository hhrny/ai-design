# 模块与接口设计

## 1. 模块划分

| 模块 | 职责 | 拥有的数据/规则 | 不负责 |
|---|---|---|---|
| Workspace Core | 工作区发现、配置、路径安全、临时事务目录 | workspace.yaml、目录约束 | 业务 Schema 内容 |
| Schema Registry | 加载并校验对象 Schema、版本和迁移 | schemas/ | Git 提交和索引查询 |
| Object Service | 对象创建、读取、更新、revision 与规范化哈希 | 对象信封规则 | 关系和评审结论逻辑 |
| Relation Service | 关系词典、方向、类型、基数和断链检查 | relation-types.yaml、relations/ | 工作流时序 |
| State Policy | 生命周期转换、角色和门禁 | 转换规则 | 身份认证实现 |
| Review Service | 评审目标、finding、action、decision | Review Schema | 判断调用方是否具有审批权限 |
| Baseline Service | 创建与验证不可变基线 | baselines/ | 修改历史基线 |
| Indexer | 从 Git 文件构建 SQLite 投影 | .workspace/index.db | 业务写入 |
| Query Service | trace、coverage、孤立对象和看板查询 | 只读 SQLite | 修复权威数据 |
| Sync Orchestrator | 标准同步请求、幂等、重试和结果落盘 | sync/attempts、ExternalReference | 平台专属字段转换 |
| Platform Adapter | RR/云龙协议映射和错误映射 | adapter 版本化实现 | 领域状态决定 |
| Artifact Renderer | 从对象生成受控 Markdown 区域 | 生成模板与 ownership | 覆盖人工叙述区 |
| Audit Writer | 生成不可变操作事件 | audit events | 保存秘密或完整敏感载荷 |

依赖方向固定为：CLI → 领域服务 → 仓库端口；Indexer/Query 只能读取领域文件或 SQLite，不得反向修改对象。

## 2. 统一命令接口

所有命令支持 `--output json`，并返回：

```json
{
  "ok": false,
  "command": "object.update",
  "correlationId": "01J...",
  "result": null,
  "warnings": [],
  "errors": [
    {
      "code": "REVISION_CONFLICT",
      "message": "Expected revision 4 but current revision is 5",
      "path": "objects/solution-design/SOL-001.yaml",
      "objectId": "SOL-001",
      "details": {"expected": 4, "actual": 5}
    }
  ]
}
```

退出码：0 成功；2 输入或 Schema 错误；3 状态/门禁冲突；4 revision 冲突；5 外部系统暂时错误；6 外部系统永久错误；7 工作区或索引损坏。

## 3. 对象接口

### object create

输入：kind、projectId、title、spec 文件或标准输入、actor。输出：新对象 ID、revision=1、contentHash 和路径。

校验：kind 已注册、ID 唯一、spec 合法、路径未逃逸工作区。创建不自动 Git commit。

### object update

输入：objectId、expectedRevision、JSON Merge Patch 或完整候选对象、actor、changeSummary。

处理：读取当前对象 → revision 比较 → 应用变更 → Schema 校验 → 规范化哈希 → 写候选集 → 原子替换。输出新 revision 和前后哈希。

若规范化内容未变化，返回 `NO_CHANGE`，不增加 revision。

## 4. 关系接口

### relation add

输入：sourceRef、predicate、targetRef、expected source revision、actor。

校验：

- source/target 存在，或跨仓引用满足允许的 Unresolved 策略。
- predicate 在词典中。
- source/target kind 满足类型规则。
- 不违反唯一性和基数。
- 不产生禁止的自引用或环路。

输出：Relation ID 和受影响的追溯路径。

### relation check

返回非法关系、断链、循环、孤立对象和违反覆盖规则的对象清单；不自动修复。

## 5. 状态转换接口

### transition

输入：objectId、expectedRevision、targetStatus、actor、source、evidenceRefs。

执行顺序：

1. 校验转换边存在。
2. 记录 actor/source；审批授权由工作区外部流程负责。
3. 评估门禁表达式。
4. 写入新 revision 和 AuditEvent。
5. 若转换到 Approved，要求关联 ReviewDecision 和 Baseline。

主要错误：`TRANSITION_NOT_ALLOWED`、`GATE_NOT_SATISFIED`、`BLOCKING_FINDINGS_OPEN`。

## 6. 评审接口

### review start

输入：subject object/revision 或 baseline、reviewType、reviewers、checklistVersion。输出 Draft Review。

### review finding add/update

finding 包含 severity、category、description、owner、dueAt、status、resolution 和 evidence。Critical/High 未关闭时，默认阻止 Passed。

### review decide

输入：reviewId、decision、actor、source、rationale、evidenceRefs。工作区记录调用方提供的 Passed、PassedWithActions、Rework 或 Rejected，不判断调用方审批权限。决策创建后不可改写；撤销需创建新的 ReviewDecision 并关联 supersedes。

## 7. 基线接口

### baseline create

输入：baselineType、root objects、relation inclusion policy、artifact policy、current Git commit、actor。

前置条件：工作树策略满足要求、对象和关系有效、Artifact 可解析、索引非 stale。输出不可变 Baseline 文件及清单哈希。

### baseline verify

检查 commit、Schema Registry hash、对象/关系/Artifact hash。返回 Missing、Changed、Unresolved、Valid 四类结果，不修改文件。

## 8. 索引接口

### index rebuild

输入：工作区路径、可选 commit。输出 index version、commit SHA、对象/关系计数、耗时和警告。

实现约束：在临时数据库中完成；启用外键；完成 `integrity_check`；成功后原子替换；旧索引在失败时保留。

### index status

比较 index_meta 与当前 Git SHA、Schema Registry hash 和工作树修改。状态为 Fresh、Stale、Missing 或 Invalid。

## 9. 查询接口

### trace

输入：objectId、方向 upstream/downstream/both、predicate 集合、最大深度、是否跨仓。输出节点、边、断链和每条路径，不返回仅靠猜测得到的关系。

### coverage

首期规则：PRD Requirement 是否有下游 IR/SR/US、SR 是否有验收标准、RequirementItem 是否可追溯到 RR 和批准 PRD、是否存在孤立对象。

查询检测索引 stale；普通读取可带警告继续，高风险门禁与基线命令必须先刷新。

## 10. 同步端口

```text
validate(domain_request) -> ValidationResult
submit(domain_request, idempotency_key) -> SubmitResult
get_status(external_request_id) -> SyncResult
cancel(external_request_id) -> Unsupported | CancelResult
```

标准错误分类：Validation、Authentication、Authorization、Conflict、RateLimited、Timeout、Unavailable、PermanentFailure、UnknownOutcome。

`Timeout` 和 `UnknownOutcome` 不能直接重试创建；必须先按 idempotency key 或 external request ID 查询，避免重复记录。

## 11. Schema 与兼容策略

- 每个对象携带 apiVersion 和 schemaVersion。
- Registry 明确支持版本范围；未知 major 版本拒绝处理。
- Minor 版本只允许向后兼容新增可选字段。
- 破坏性变化提供显式 migration 命令，迁移结果必须经过 Diff 和人工提交。
- CLI JSON 输出也具有版本，Agent 不应解析面向人的文本输出。

## 12. 安全边界

- 所有路径经规范化后必须位于工作区内。
- Platform Adapter 只能接收完成最小化的数据传输对象。
- 凭证由外部提供方注入，不允许出现在命令参数、事件、对象或索引中。
- actor 与 source 作为审计元数据保存；本工作区不绑定企业审批权限系统。
- 所有生成文件先在临时目录校验，防止部分写入和路径穿越。

## 13. 首期实现顺序

1. Workspace Core、Schema Registry、Object Service。
2. Relation Service、State Policy、Audit Writer。
3. Indexer、Query Service。
4. Review Service、Baseline Service。
5. Sync Orchestrator 与模拟 Adapter。
6. Artifact Renderer 和覆盖率检查。

每一阶段都必须带契约测试和一个端到端 fixture，不能只实现模块单元测试。
