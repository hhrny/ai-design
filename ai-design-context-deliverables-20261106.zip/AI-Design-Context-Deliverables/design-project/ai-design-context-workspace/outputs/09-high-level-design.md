# 总体方案设计说明书

## 1. 架构结论

系统采用四层结构：

```mermaid
flowchart TB
    A[Agent / Skill / 人工用户] --> C[Workspace CLI]
    C --> V[Schema、关系、状态机、revision 校验]
    C --> G[Git 工作区：权威对象与交付物]
    G --> I[Indexer / Projector]
    I --> S[(SQLite 本地查询索引)]
    C --> Q[Trace / Review / Baseline 查询]
    Q --> S
    C --> P[平台适配器]
    P --> E[RR / 云龙模拟或真实平台]
    P --> G
```

- **Git 工作区**：唯一业务事实源，保存结构化对象、关系、基线、阅读文档和工程交付物。
- **Workspace CLI**：唯一受控写入入口，负责校验、状态转换、revision、评审、基线和同步编排。
- **SQLite 索引**：当前 Git Checkout 的只读查询投影，可删除、可重建，不接受业务写入。
- **平台适配器**：隔离 RR、云龙等外部系统，返回结果转换为标准 ExternalReference 和 SyncAttempt 后写回 Git。

## 2. 系统边界

系统负责本地设计对象和关系的数据契约、对象 revision、状态转换、评审、基线、追溯、Git 工作区一致性修改、SQLite 索引，以及外部平台调用的适配、幂等、重试和审计。

系统不替代 Git 服务端的身份、权限、Pull Request 或分支策略，不替代 RR/云龙作为其正式记录的权威来源，不提供多人实时编辑或中心数据库。审批授权不属于当前范围；系统只记录外部流程或调用方提供的评审结论、actor、source 和固定 revision。

## 3. 仓库布局

```text
design-workspace/
├── workspace.yaml
├── schemas/
│   ├── common/
│   ├── objects/
│   └── relation-types.yaml
├── objects/
│   ├── requirement-analysis/
│   ├── solution-design/
│   ├── prd/
│   ├── reviews/
│   └── requirement-items/
├── relations/
│   └── <source-object-id>.yaml
├── external-references/
│   └── <object-id>.yaml
├── baselines/
│   └── <baseline-id>.yaml
├── artifacts/
│   ├── requirements/
│   ├── solutions/
│   ├── prd/
│   └── prototypes/
├── sync/attempts/
├── .workspace/
│   ├── index.db
│   └── cache/
└── .gitignore
```

`.workspace/` 整体忽略。结构化对象按对象拆分为小文件，避免所有关系或需求集中在单一大文件中造成不必要的 Git 冲突。

## 4. 统一对象模型

### 4.1 对象信封

所有业务对象遵循相同的顶层结构：

```yaml
apiVersion: design.openai.local/v1
kind: SolutionDesign
metadata:
  id: SOL-001
  projectId: PROJ-001
  title: 用户权限高阶方案
  revision: 4
  schemaVersion: 1.0.0
  lifecycleStatus: Approved
  owner: role:solution-architect
  createdAt: 2026-11-05T08:00:00Z
  updatedAt: 2026-11-05T10:30:00Z
  contentHash: sha256:...
spec:
  overview: {}
```

`metadata.id` 是稳定身份，采用 19 位纯数字格式 `YYYYMMDDHHmmssRRRRR`：前 14 位为精确到秒的日期时间，后 5 位为 `00000`～`99999` 的随机数。实现建议统一使用 UTC；创建前必须检查工作区与索引唯一性，碰撞时重新生成。对象类型由 `kind` 表达，不嵌入 ID。`metadata.revision` 是乐观锁与历史引用单位；外部平台编号绝不进入主键。该规则见 [DEC-003](../decisions/DEC-003.md)。

### 4.2 Revision 模型

- 当前对象文件保存最新 revision。
- 每次受控修改要求 `expectedRevision`。
- CLI 对规范化内容计算 `contentHash`，revision 只在有效内容或受控元数据变化时递增。
- Git Commit 提供文件历史，Baseline 固定对象 ID、revision、contentHash 和 commit SHA。
- 若未来需要不依赖 Git 读取历史 revision，可增加导出快照，但首期不重复保存完整历史对象。

### 4.3 核心对象

| kind | 主要职责 |
|---|---|
| RequirementAnalysis | 场景、问题、约束、假设、待确认问题和确认需求 |
| SolutionDesign | 架构、接口、数据、安全、NFR 和专业决策引用 |
| PRD | 功能、业务规则、验收标准和结构化 PRD 需求项 |
| Review | 评审目标 revision/baseline、评审人、finding、action 和 decision |
| RequirementItem | 统一封装 RR/IR/SR/US，使用 requirementType 区分 |
| Baseline | 固定对象 revision、关系、Artifact 和 Git Commit SHA |

RequirementItem 首期使用统一 kind，以复用公共字段和追溯规则；当 IR/SR/US 的强约束显著分化时，可通过 `oneOf` Schema 或独立 kind 演进。

## 5. 公共对象与关系词典

### 5.1 Relation

```yaml
id: REL-001
source:
  repositoryId: core-design
  objectId: SOL-001
  revision: 4
predicate: DERIVED_FROM
target:
  repositoryId: core-design
  objectId: RA-001
  revision: 2
status: Active
```

关系词典至少包含：

| Predicate | Source | Target | 语义 |
|---|---|---|---|
| DERIVED_FROM | 派生对象 | 来源对象 | source 来源于 target |
| DECOMPOSED_INTO | RR/IR/PRD Requirement | IR/SR/US | source 被拆分为 target |
| SATISFIES | 方案/需求项 | 上游需求 | source 满足 target |
| CONSTRAINS | SR/约束 | US/方案 | source 约束 target |
| SUPPORTS | IR/SR/US | 目标需求 | source 支撑 target |
| REFERENCES | 允许的任意对象 | 允许的任意对象 | 非控制性引用 |
| REVIEWED_BY | 被评审对象 | Review | source 由 target 评审 |
| BASELINED_BY | 对象/Artifact | Baseline | source 被 target 固定 |
| SUPERSEDES | 新对象或 revision | 旧对象或 revision | source 替代 target |

`GENERATES`、`INPUT_TO` 等容易与 `DERIVED_FROM` 重叠的谓词不进入首期词典；流程依赖由门禁表达，不滥用 Relation 表达时序。

### 5.2 Artifact

Artifact 保存文件引用而非复制内容，并记录 repositoryId、path、commitSha、checksum、generatedFrom 和字段所有权。生成区域与人工区域必须明确，生成器不能覆盖人工叙述区。

### 5.3 ExternalReference

ExternalReference 保存本地 objectId、platform、externalType、externalId、externalUrl、syncStatus 和最近成功的 SyncAttempt。平台响应与错误细节进入独立 SyncAttempt，避免频繁改写映射对象。

## 6. 状态与门禁

系统分开表达四类状态：

1. **WorkflowNodeStatus**：NotStarted、Ready、InProgress、Blocked、Completed、Skipped、Failed。
2. **LifecycleStatus**：Draft、InReview、ChangesRequested、Confirmed、Approved、Superseded、Rejected、Archived。
3. **ReviewDecision**：Pending、Passed、PassedWithActions、Rework、Rejected。
4. **SyncStatus**：NotSynced、Pending、Syncing、Synced、SyncFailed、Conflict。

对象只使用其 Schema 允许的状态子集。状态转换规则包含当前状态、目标状态、前置条件、产生事件和失败错误码；actor 与 source 仅用于审计，不在本工作区内进行审批权限判断。

需求拆分门禁：

```text
start_decomposition =
  PRD.lifecycleStatus == Approved
  AND RR.externalReference.syncStatus == Synced
  AND RR.externalReference.externalId exists
  AND blocking_open_findings(PRD baseline) == 0
```

完成节点不能直接由调用者设置；CLI 根据交付物、检查结果和门禁计算。

## 7. CLI 与写入模型

首期命令组：

```text
workspace validate [path]
workspace object create|update|show
workspace relation add|remove|check
workspace transition <object> <target-status>
workspace index rebuild|status
workspace trace <object-id>
workspace review start|finding|decide
workspace baseline create|verify
workspace sync submit|status|retry
```

所有修改命令遵循统一事务流程：

1. 读取对象和当前 Git 状态。
2. 验证 expected revision、Schema、关系和门禁。
3. 在临时目录生成完整候选文件集。
4. 对候选集执行相关全量校验。
5. 将候选文件原子替换到工作树。
6. 记录结构化 AuditEvent。
7. 增量刷新索引；若失败，Git 文件仍为事实，提示重建索引。

CLI 不自动提交 Git，以避免代表用户产生未授权的版本控制操作；提交由人工或明确的上层工作流执行。

## 8. SQLite 查询投影

首期索引表：

```text
index_meta(commit_sha, schema_registry_hash, built_at, index_version)
objects(id, kind, project_id, revision, status, title, content_hash, source_path)
object_content(object_id, normalized_json)
relations(id, source_id, predicate, target_id, source_revision, target_revision)
artifacts(id, object_id, path, commit_sha, checksum, artifact_type)
external_refs(id, object_id, platform, external_type, external_id, sync_status)
reviews(id, subject_id, subject_revision, decision, status)
review_findings(id, review_id, severity, status, owner)
baselines(id, baseline_type, git_commit_sha, created_at)
baseline_items(baseline_id, item_type, item_id, revision, content_hash)
```

公共字段关系化以便索引；类型专属内容保留为规范 JSON。索引器使用外键、唯一约束和必要的 CHECK 约束发现投影错误，业务 Schema 仍由 CLI 校验。

重建时扫描权威目录，在 `index.db.tmp` 构建并执行完整性检查。对象数、关系数、规范哈希和引用检查通过后才原子替换。`index_meta.commit_sha` 与当前 Checkout 不一致时，查询显示 stale；风险命令拒绝依赖过期索引。

## 9. 评审与基线

评审目标为 `{repositoryId, objectId, revision, contentHash}` 或 Baseline ID。评审期间对象更新不改变已有评审目标。

Baseline 清单包括：

- 对象 ID、revision、contentHash。
- 参与基线的 Relation ID 与内容哈希。
- Artifact path、commit SHA、checksum。
- Schema Registry hash。
- 创建者、创建时间、基线类型和来源评审。

Baseline 不可修改；新基线通过 `SUPERSEDES` 连接旧基线。

## 10. 平台同步

平台集成采用端口/适配器结构：

```text
Domain Sync Request
  -> Adapter.validate()
  -> Adapter.submit(idempotency_key, payload)
  -> Adapter.get_status(external_request_id)
  -> Standard SyncResult
  -> ExternalReference + SyncAttempt 写回 Git
```

SyncAttempt 至少保存 attempt ID、object ID、adapter version、idempotency key、请求摘要、响应摘要、开始/结束时间、结果、错误类别和 retry-of。凭证和完整敏感载荷不得写入 Git 或日志。

首期模拟适配器支持成功、超时、可重试错误、永久错误和部分成功五种确定性场景。

## 11. 安全与外部职责

- 审批权限由工作区外部的现有流程或调用方负责；工作区只保存评审结论、actor、source 与证据引用。
- 外部平台凭证只通过环境或企业凭证提供方注入，不写入对象、SQLite 或日志。
- 日志默认记录摘要和哈希，不记录完整需求载荷。
- 生产接入前完成数据分类、终端存储、日志保留和加密评审。
- Git 仓库访问控制仍由企业 Git 平台负责，本系统不复制权限系统。

## 12. 可靠性与失败模式

| 失败模式 | 处理 |
|---|---|
| 索引构建失败 | 保留旧索引；输出具体无效文件；Git 事实不受影响 |
| CLI 写入中断 | 候选文件位于临时目录；未完成时不替换工作树 |
| revision 冲突 | 返回 Conflict 和当前 revision；调用者重新读取并合并 |
| 平台超时 | 以同一幂等键查询或重试；不假定失败等于未创建 |
| 部分平台成功 | 每个对象独立记录状态；整体保持 PartiallyCompleted |
| Artifact 被移动 | 校验 path 失败；通过对象引用和 Git 历史定位，更新需新 revision |
| Schema 升级 | 使用 schemaVersion 和显式 migration；禁止静默解释新字段 |
| 跨仓引用不可达 | 标记 Unresolved，不删除关系；基线创建时按策略阻断 |

## 13. 可观测性

- CLI 输出稳定 JSON envelope：`ok`、`command`、`result`、`warnings`、`errors`、`correlationId`。
- 每次写入生成 AuditEvent，携带 actor、source、affected IDs 和前后哈希。
- 索引记录构建耗时、对象/关系数量、无效对象数和 commit SHA。
- 同步记录尝试次数、错误类别、延迟和最终结果，不记录秘密。

## 14. 演进路线

1. **契约与闭环**：完成 Schema Registry、关系词典、CLI 校验、全量索引、追溯、评审、基线和模拟同步。
2. **体验与规模**：根据试点数据增加增量索引、生成视图、覆盖率检查、批量操作和 CI 集成。
3. **真实平台与跨仓**：接入 RR/云龙适配器、跨仓解析器和安全要求。
4. **架构重评估**：只有真实数据证明需要时，评估中心化上下文服务或 SQLite/Git 发布协议。任何变化必须形成新架构决策，不在当前实现中预埋双事实源。
