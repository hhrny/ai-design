# 需求分析说明书（MVP 基线）

## 1. 基线结论

首期建设一个 **Git 驱动、SQLite 加速、CLI 管一致性** 的 AI 辅助设计工作空间。权威结构化对象和交付物进入 Git；SQLite 是当前 Checkout 的派生索引；Agent/Skill 只能通过 Workspace CLI 执行对象变更、状态转换、评审和基线操作。

本基线采用已确认决策：

- [DEC-001](../decisions/DEC-001.md)：Git 为事实源，SQLite 为索引。
- [DEC-002](../decisions/DEC-002.md)：首期采用最小端到端闭环。
- [DEC-003](../decisions/DEC-003.md)：稳定本地 ID 使用日期到秒数字加 5 位随机数。
- [DEC-004](../decisions/DEC-004.md)：PRD 使用 YAML 事实源、Markdown 生成块和人工叙述区。

## 2. MVP 业务闭环

1. 创建需求分析对象并形成固定 revision。
2. 基于需求分析创建高阶方案，可选关联 Demo/高保真 Artifact。
3. 对高阶方案基线进行评审并记录 finding、整改和审批结论。
4. 评审通过后并行创建 PRD 和原始 RR 登记任务。
5. PRD Approved 与 RR Ready 同时满足后开放需求拆分。
6. 拆分生成 IR/SR/US 需求项及多对多关系。
7. 通过模拟适配器登记外部编号并以元数据 revision 回刷。
8. 查询任一 SR/US 的端到端来源，并恢复任一已建基线。

## 3. 权威对象范围

| 类别 | 首期对象 | 权威形式 |
|---|---|---|
| 核心业务对象 | RequirementAnalysis、SolutionDesign、PRD、Review、RequirementItem、Baseline | Git 中 YAML；由 JSON Schema 校验 |
| 公共对象 | Relation、Artifact、ExternalReference | Git 中 YAML 或嵌入式清单，具体由高阶设计确定 |
| 阅读交付物 | 需求分析、方案、PRD Markdown；原型、架构图、附件 | Git 文件 |
| 查询投影 | objects、relations、reviews、external_refs、baselines 等索引表 | 本地 SQLite，可重建 |

## 4. 关键流程规则

- Demo 与高保真是可选评审输入，不是硬前置条件。
- 高阶方案评审通过后，PRD 与原始 RR 登记可以并行。
- 需求拆分门禁为 `PRD Approved AND RR Ready AND RR number exists`。
- 拆分后的 IR/SR/US 平台登记与原始 RR 登记是不同的同步阶段。
- 编号回刷不重新打开 PRD 业务评审；业务内容变化则必须生成新 revision 并重新评审。
- WorkflowNode 完成由产物、finding 和门禁计算，不能直接写入完成状态绕过检查。

## 5. 需求覆盖关系

| 业务目标 | 主要需求 |
|---|---|
| 统一对象协议 | FR-001～FR-006、QR-005、QR-010 |
| 受控流程与评审 | FR-007～FR-013、QR-003、QR-009 |
| 端到端追溯 | FR-004、FR-012、FR-014、FR-022 |
| 单一事实源 | FR-016、FR-017、QR-001、QR-002、QR-004 |
| 多 Agent 安全协作 | FR-009、QR-006 |
| 平台集成边界 | FR-003、FR-015、FR-019、QR-008 |

完整逐项定义见 [结构化需求清单](04-requirement-catalog.md)。

## 6. MVP 验收场景

| ID | 场景 | 通过条件 |
|---|---|---|
| AT-01 | 索引全量重建 | 删除索引后重建，对象数、关系数和规范内容哈希一致 |
| AT-02 | 非法关系 | 错误方向或类型组合被拒绝并定位到文件和字段 |
| AT-03 | 并发更新 | 相同 expected revision 的第二次提交返回冲突 |
| AT-04 | 评审冻结 | 被评审对象产生新 revision 时，原评审仍固定旧 revision |
| AT-05 | 双门禁 | 只有 PRD Approved 或只有 RR Ready 时均不能拆分 |
| AT-06 | 端到端追溯 | SR 可追溯至 IR、RR、PRD 需求项、方案和需求分析 |
| AT-07 | 幂等同步 | 同一 idempotency key 重试不会生成重复外部记录 |
| AT-08 | 编号回刷 | 回刷后业务内容哈希不变，元数据 revision 与审计记录新增 |
| AT-09 | 基线恢复 | Checkout 基线 commit 后，所有基线项与记录哈希一致 |

## 7. 风险与缓解措施

| 风险 | 严重度 | 缓解措施 |
|---|---|---|
| YAML 与 Markdown 重复维护 | 高 | 建立字段所有权清单；生成区不可手工编辑 |
| 关系谓词持续膨胀或语义重叠 | 高 | 首期限定关系词典；新增谓词需设计评审 |
| SQLite 被直接写入 | 高 | 数据库文件标记为派生物；CLI 不提供业务写接口；CI 进行重建一致性检查 |
| 真实平台契约未知 | 中 | 使用适配器与模拟实现；真实接入前关闭 O-04 |
| 父子仓历史引用漂移 | 中 | 基线只使用 commit SHA，不使用浮动分支作为恢复依据 |
| 对象粒度过细导致维护成本高 | 中 | 首期仅六类核心对象；以真实试点数据校准拆分粒度 |

## 8. 开放事项

- O-03：首个真实试点项目与仓库边界。
- O-04～O-06：真实平台接口、回刷格式和安全要求。

审批权限不属于当前范围，PRD 字段所有权已经确认。剩余事项不阻塞本地 MVP，但 O-03～O-06 需要在对应试点或平台接入前关闭。

## 9. 基线质量检查

- 范围：首期纳入与排除项已明确。
- 一致性：事实源模式与 SQLite 索引定位一致。
- 可验证性：Must 需求均具备验收信号。
- 可追溯性：业务目标、场景、需求和测试已建立映射。
- 未决事项：均显式记录，没有以推断代替用户决定。
- 主要限制：真实企业平台资料尚未提供，当前仅能完成适配器边界设计。
